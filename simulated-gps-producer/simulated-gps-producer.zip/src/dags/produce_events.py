import asyncio
import json
import math
import random
from datetime import datetime, timedelta
import time
import os
import shutil
from pathlib import Path
import logging
from typing import Iterator
from airflow.decorators import dag
from aiokafka import AIOKafkaProducer
from aiokafka.producer.message_accumulator import BatchBuilder
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F, types as T
from src.schema import simulated_gps_data_schema


KAFKA_BOOTSTRAP_SERVER = "localhost:9092"
KAFKA_TOPIC = "taxi_gps_stream"
MINUTE = 60_000
SECOND = 1_000

dir = os.path.dirname(__file__)
SIMULATED_GPS_DATA_BASE_PATH = dir + "/../data/generated/simulated_gps"
SPARK_READ_DIR_PATH = dir + "/../data/spark_stream_read/"

PARTITIONED_DIR = dir / Path("../data/generated/simulated_gps")
INGESTION_DIR = dir / Path("../data/ingestion/")

#def create_spark_session() -> SparkSession:
#    try:
#        spark: SparkSession = (
#            SparkSession.builder
#            .appName("Preprocessed data reader / transformer")
#            .master("local[*]")
#            .getOrCreate()
#        )
#
#        return spark
#
#    except Exception as e:
#        logging.error(f"Failed to create Spark session. {e}")
#        raise(e)
#
#
#def read_stream_gps_data_by_second(
#        spark: SparkSession,
#        current_datetime: datetime
#) -> DataFrame | None:
#    path: str = SIMULATED_GPS_DATA_DIR_PATH + f"/hour={current_datetime.hour}/minute={current_datetime.minute}/second={current_datetime.second}"
#    return (
#        #spark.read
#        spark.readStream
#        .schema(simulated_gps_data_schema)
#        #.option("inferSchema", True)
#        .option("path", path)
#        .option("header", True)
#        .load()
#    )


#def random_delay_in_sec() -> float:
#    return random.randint(1000, 4000) / 1000
#
#
#def calc_delay(target_second: int, current_second: int) -> float:
#    if target_second < current_second:
#        return 0.0
#    
#    diff: int = target_second - current_second
#
#    return diff + random_delay_in_sec()
#
#
#def add_event_datetime(row: T.Row, current_datetime: datetime) -> T.Row:
#    dict = row.asDict()
#
#    event_datetime: datetime = datetime(
#        current_datetime.year,
#        current_datetime.month,
#        current_datetime.day,
#        dict.pop("hour", None),
#        dict.pop("minute", None),
#        dict.pop("second", None),
#        math.ceil(dict.pop("microsecond", None)),
#    ) 
#
#    # timestamp `Long` in milliseconds 
#    dict["timestamp"] = event_datetime.timestamp() * 1000
#    
#    return T.Row(**dict)
#
#
#async def kafka_send_rows(
#    producer: AIOKafkaProducer,
#    rows: list[T.Row],
#    target_second: int,
#    current_datetime: datetime
#):
#    batch: BatchBuilder = producer.create_batch()
#
#    for row in rows:
#        #enriched_row: T.Row = add_event_datetime(row, current_datetime)
#        batch.append(
#            key=None,
#            value=json.dumps(row.asDict()).encode("utf-8"),
#            timestamp=None
#        )
#
#    delay: float = calc_delay(target_second, current_datetime.second)  
#    await asyncio.sleep(delay)
#
#    partitions: set[int] = await producer.partitions_for(KAFKA_TOPIC)
#    partition: int = random.choice(tuple(partitions))
#
#    return producer.send_batch(batch, KAFKA_TOPIC, partition=partition)
#
#
#async def schedule_kafka_messages(
#        producer: AIOKafkaProducer,
#        rows: list[T.Row],
#        target_second: int,
#        current_datetime: datetime,
#) -> None:
#    cnt: int = len(rows)
#    chunk_amount: int = 4
#    rows_per_chunk: int = math.ceil(cnt / chunk_amount)
#    rows_split: list[list[T.Row]] = [
#        rows[i:i + rows_per_chunk] for i in range(0, cnt, rows_per_chunk)
#    ]
#
#    sent_batch = [
#        kafka_send_rows(
#            producer, 
#            rows_split[chunk_index], 
#            target_second, 
#            current_datetime
#
#        ) for chunk_index in range(0, chunk_amount) 
#    ]
#
#    [(await (await task)) for task in sent_batch]


#def read_stream_gps_data(
#    spark: SparkSession,
#    now: datetime
#) -> DataFrame | None:
#
#    path: str = SIMULATED_GPS_DATA_BASE_PATH + f"/hour={now.hour}/minute={now.minute}/second={now.second}"
#    print(path)
#
#    if not os.path.exists(path):
#        return None
#
#    print("Fetching have started")
#    return (
#        spark.readStream
#        .schema(simulated_gps_data_schema)
#        #.option("inferSchema", True)
#        .option("header", True)
#        #.option("basePath", "file://" + SIMULATED_GPS_DATA_BASE_PATH)
#        .parquet("file://" + path)
#        .select(
#            F.col("trip_id").cast("string").alias("key"),
#            F.to_json(
#                F.struct(
#                    "lat",
#                    "lon",
#                    F.make_timestamp(
#                        F.lit(now.year),
#                        F.lit(now.month),
#                        F.lit(now.day),
#                        F.hour("timestamp"),
#                        F.minute("timestamp"),
#                        F.second("timestamp") + F.expr("microsecond / 1000000")
#                    ).alias("timestamp"),
#                    "fare_amount",
#                    "tip_amount",
#                    "total_profit"
#                )
#            ).cast("string").alias("value")
#        )
#    )



#@dag(
#    default_args={
#        "depends_on_past": False,
#        "retries": 2,
#        "retry_delay": timedelta(seconds=1),
#    },
#    dag_id="per_minute_gps_event_producer",
#    schedule="* * * * *",
#    start_date=datetime.now(),
#    catchup=False,
#    dagrun_timeout=timedelta(minutes=1),
#)
#async def run_producer_per_minute () -> None:
#    spark: SparkSession = create_spark_session()
#
#    producer: AIOKafkaProducer = AIOKafkaProducer(bootstrap_servers=KAFKA_BOOTSTRAP_SERVER)
#    await producer.start()
#
#    current_ts: int = int(time.time())
#    print("fetching have started")
#    #rows: DataFrame = get_df_simulated_gps_per_minute(spark, current_ts)
#    #print(rows.count())
#    rows: DataFrame = list(get_df_simulated_gps_per_minute(spark, current_ts).toLocalIterator())
#    gps_data_rows_per_second: list[list[T.Row]] = [
#        [row for row in rows if row.simulated_event_time_second == second] for second in range(0, 60)
#    ]
#    print("fetching have completed")
#
#    try:
#        tasks = []
#        for second, rows_of_second in enumerate(gps_data_rows_per_second):
#            print(second, " appending")
#
#            tasks.append(
#                asyncio.create_task(
#                    schedule_kafka_messages(
#                        producer, 
#                        rows_of_second,
#                        second,
#                        datetime.now()
#                    )
#                )
#            )
#            print(second, " appended")
#
#        print("awaiting after loop")
#        [(await task) for task in tasks]
#
#    finally:
#        await producer.stop()

#def trunc_microseconds(dt: datetime) -> datetime:
#    return dt.replace(microsecond=0)


def get_partition_path() -> Path:
    now = datetime.now()
    return PARTITIONED_DIR / f"hour={now.hour}" / f"minute={now.minute}" / f"second={now.second}"


def copy_parquets(src_dir: Path, dst_dir: Path) -> bool:
    print(src_dir)
    if not src_dir.exists():
        print("No files")
        return False

    files: Iterator[Path] = src_dir.glob("*.parquet")
    if not files:
        print("No parquet files")
        return False

    for file in files:
        dst_file: Path = dst_dir / file
        shutil.copy2(file, dst_file)
        print("Copied!")
    
    return True


async def feed_ingestion_per_second() -> None:
    print("Started to copy parquet files")
    INGESTION_DIR.mkdir(parents=True, exist_ok=True)

    while True:
        partition_path = get_partition_path()
        copy_parquets(partition_path, INGESTION_DIR)
        await asyncio.sleep(1)


def write_to_kafka_per_second(spark: SparkSession) -> None:
    now: datetime = datetime.now()

    df: DataFrame = (
        spark.readStream
        .schema(simulated_gps_data_schema)
        .option("header", True)
        .parquet(INGESTION_DIR.absolute().as_posix())
        .select(
            F.col("trip_id").cast("string").alias("key"),
            F.to_json(
                F.struct(
                    "lat",
                    "lon",
                    F.make_timestamp(
                        F.lit(now.year),
                        F.lit(now.month),
                        F.lit(now.day),
                        F.hour("timestamp"),
                        F.minute("timestamp"),
                        F.second("timestamp") + F.expr("microsecond / 1000")
                    ).cast("long").alias("timestamp"),
                    "fare_amount",
                    "tip_amount",
                    "total_profit"
                )
            ).cast("string").alias("value")
        )
    )

    (df.writeStream
     .format("kafka")
     .trigger(processingTime="1 second")
     .option("kafka.bootstrap.servers", KAFKA_BOOTSTRAP_SERVER)
     .option("topic", KAFKA_TOPIC)
     .option("checkpointLocation", "/tmp/spark_checkpoint/")
     .start()
     .awaitTermination()
     )
    #spark: SparkSession = create_spark_session()

    #last_run_at: datetime = datetime(1970, 1, 1)

    #while True:
    #    now: datetime = datetime.now()
    #    print(now)

    #    if trunc_microseconds(last_run_at) == trunc_microseconds(now):
    #        time.sleep(0.2)
    #        continue

    #    df: DataFrame | None = read_stream_gps_data(spark, now)

    #    if not df:
    #        time.sleep(1)
    #        continue

    #    print("Fetched")
    #    (df.writeStream
    #     .format("kafka")
    #     .option("kafka.bootstrap.servers", KAFKA_BOOTSTRAP_SERVER)
    #     .option("topic", KAFKA_TOPIC)
    #     .option("checkpointLocation", "/tmp/spark_checkpoint/")
    #     .start()
    #     #.awaitTermination()
    #     )

    #    last_run_at = now

async def main(spark: SparkSession) -> None:
    asyncio.create_task(feed_ingestion_per_second())
    write_to_kafka_per_second(spark)
    


#if __name__ == "__main__":
#     #asyncio.run(run_producer_per_minute())
#    main()
